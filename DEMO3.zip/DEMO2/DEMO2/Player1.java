import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Player1 extends Actor
{
    //Player1 Status
    private int speed;
    private int directionX;
    private int directionY;
    private boolean death;
    private boolean hitStun = false;
    private Score playerScore;
    private HeartBar healthBar;
    private WeaponInventory inventory;
    //For handling all the weapon use stuff
    private Weapon currentWeapon;
    private int rotation ;
    private int shootDirX;
    private int shootDirY;
    private boolean shootFlag;
    private int cooldown = 0;
    //For Handling the animations
    private int frame = 0;
    private int steps = 0;
    private GreenfootImage idleFront = new GreenfootImage("Player1IdleFront.png");
    private GreenfootImage idleBack = new GreenfootImage("Player1IdleBack.png");
    private GreenfootImage idleLeft = new GreenfootImage("Player1IdleLeft.png");
    private GreenfootImage idleRight = new GreenfootImage("Player1IdleRight.png");
    private GreenfootImage pointFront = new GreenfootImage("Player1PointFront.png");
    private GreenfootImage pointBack = new GreenfootImage("Player1PointBack.png");
    private GreenfootImage pointLeft = new GreenfootImage("Player1PointLeft.png");
    private GreenfootImage pointRight = new GreenfootImage("Player1PointRight.png");
    private GreenfootImage walkDown[] = {new GreenfootImage("frontWalk1.png"),new GreenfootImage("frontWalk2.png"),new GreenfootImage("frontWalk3.png"), new GreenfootImage("frontWalk4.png"),new GreenfootImage("frontWalk5.png"),new GreenfootImage("frontWalk6.png"),new GreenfootImage("frontWalk7.png"),new GreenfootImage("frontWalk8.png")};
    private GreenfootImage walkUp[] = {new GreenfootImage("backWalk1.png"),new GreenfootImage("backWalk2.png"),new GreenfootImage("backWalk3.png"), new GreenfootImage("backWalk4.png"),new GreenfootImage("backWalk5.png"),new GreenfootImage("backWalk6.png"),new GreenfootImage("backWalk7.png"),new GreenfootImage("backWalk8.png")};
    private GreenfootImage walkLeft[] = {new GreenfootImage("leftWalk1.png"),new GreenfootImage("leftWalk2.png"),new GreenfootImage("leftWalk3.png"), new GreenfootImage("leftWalk4.png"),new GreenfootImage("leftWalk5.png"),new GreenfootImage("leftWalk6.png"),new GreenfootImage("leftWalk7.png"),new GreenfootImage("leftWalk8.png")};
    private GreenfootImage walkRight[] = {new GreenfootImage("rightWalk1.png"),new GreenfootImage("rightWalk2.png"),new GreenfootImage("rightWalk3.png"), new GreenfootImage("rightWalk4.png"),new GreenfootImage("rightWalk5.png"),new GreenfootImage("rightWalk6.png"),new GreenfootImage("rightWalk7.png"),new GreenfootImage("rightWalk8.png")};
    private GreenfootImage actualSprite;
    private int width;
    private int height;
    
    //Constructor is only called when its created
    public Player1(int lifes)
    {
        super();
        this.healthBar = new HeartBar(lifes);
        this.playerScore = new Score(0);
        this.speed = 2;
        this.directionX = 0;
        this.directionY = 0;
        this.death = false;
        this.shootFlag = false;
        this.currentWeapon = new Weapon(5,2,new Bullet(5,700,5,1,this));
        this.inventory = new WeaponInventory(currentWeapon);
        this.rotation = 90;
        this.actualSprite = idleFront;
        this.width = this.actualSprite.getWidth() + 16;
        this.height = this.actualSprite.getHeight() + 16;
    }
    
    public WeaponInventory getInventory()
    {
        return inventory;
    }
    
    public void youAreDead(){//This remove Player in case his life is run to 0
        if(healthBar.isDeath()){
            getWorld().removeObject(this);
            Greenfoot.setWorld(new YouAreDead());
        }
    }
    
    private void cooldownStun()
    {
        if(cooldown >= 80)
        {
            hitStun = false;
            cooldown = 0;
        }
        else
        {
            cooldown++;
        }
     
    }
    //Methods for passing the ui elements that will be drawn
    public Score getPlayerScore()
    {
        return this.playerScore;
    }
    
    public HeartBar getLifes()
    {
        return this.healthBar;
    }
    
    public boolean checkTileObstacleCollision()
    {
        Actor o = null;
        //getOneObjectAtOffset(int dx, int dy, Class<?> cls)
        if(Greenfoot.isKeyDown("a")&&Greenfoot.isKeyDown("w"))
            o = getOneObjectAtOffset(-16,-16,Obstacle.class);
        else if(Greenfoot.isKeyDown("d")&&Greenfoot.isKeyDown("w"))
            o = getOneObjectAtOffset(16,-16,Obstacle.class);
        else if(Greenfoot.isKeyDown("a")&&Greenfoot.isKeyDown("s"))
            o = getOneObjectAtOffset(-16,16,Obstacle.class);
        else if(Greenfoot.isKeyDown("d")&&Greenfoot.isKeyDown("s"))
            o = getOneObjectAtOffset(16,16,Obstacle.class);
        else if(Greenfoot.isKeyDown("a"))
            o = getOneObjectAtOffset(-16,0,Obstacle.class);
        else if(Greenfoot.isKeyDown("d"))
            o = getOneObjectAtOffset(16,0,Obstacle.class);
        else if(Greenfoot.isKeyDown("s"))
            o = getOneObjectAtOffset(0,16, Obstacle.class);
        else if(Greenfoot.isKeyDown("w"))
            o = getOneObjectAtOffset(0,-16, Obstacle.class);
            
        if(o!=null)
            return true;
        else
            return false;
    }
    
    public int getRot()
    {
        return this.rotation;
    }
    
    
    public int getPlayerX() //To get acces of player x position through another object 
    {
        return getX();
    }
    
    public int getPlayerY() //To get acces of player y position through another object 
    {
        return getY();
    }
    
    //Void methods
    public void takeDamage()
    {
        if(!hitStun)
            healthBar.takeDamage(1);
    }
    
    public void resetShootFlag() {
        shootFlag = false;
    }
    
    public void shoot()
    {
        if(currentWeapon!=null)
        {
            if(Greenfoot.isKeyDown("k") && !shootFlag)
            {
                //Shoot bullet when press down
                this.directionY=this.directionX=0;
                 this.currentWeapon.shootBullet(this);
                 shootFlag = true;
            }
        }
    }
    
    private void checkForDoor(){
        CyberWorld1 world = (CyberWorld1) getWorld();
        Actor door = getOneIntersectingObject(CyberDoor.class);
        
        if(door!=null && world.areAllEnemiesDead()){
            world.changeWorld();
        }
    }
    
    public int getShootDirX()
    {
        return shootDirX;
    }
    
    public int getShootDirY()
    {
        return shootDirY;
    }
    
    public void checkInput()
    {
        //TopDown Movement
        //Check Horizontal Movement
        if(Greenfoot.isKeyDown("a")&&!checkTileObstacleCollision())
        {
             this.directionX = -1;
             this.shootDirX = -1; //Player is pointig left
             this.rotation=180;
             //System.out.println("left");
        }
        else if(Greenfoot.isKeyDown("d")&&!checkTileObstacleCollision())
        {
            this.directionX = 1;
            this.shootDirX = 1; //Player is pointing right
            this.rotation=0;
            //System.out.println("right");
        }
        else
        {
            this.directionX = 0;
        }
        
        //Check Vertical Movement
        if(Greenfoot.isKeyDown("w")&&!checkTileObstacleCollision())
        {
             this.directionY = -1;
             this.shootDirY = -1; //Player is pointing up
             this.rotation=270;
             //System.out.println("up");
        }
        else if(Greenfoot.isKeyDown("s")&&!checkTileObstacleCollision())
        {
            this.directionY = 1;
            this.shootDirY = 1; //Player is pointing down
            this.rotation=90;
            //System.out.println("down");
        }
        else
        {
            this.directionY = 0;
        }
        
        //CheckShooting input
        this.shoot();
    }
    
    //Playing animations methods
    public void walkingAnimations()
    {
        //Play animations for vertical movement
        if(Greenfoot.isKeyDown("w")||Greenfoot.isKeyDown("s"))
        {
            switch(this.directionY)
            {
                case 1:
                    this.actualSprite = this.walkDown[frame];
                    break;
                case -1:
                    this.actualSprite = this.walkUp[frame];
                    break;
            }
        }
        else //PlayAnimations for Horizontal movement
        {
            switch(this.directionX)
            {
                case 1:
                    this.actualSprite=this.walkRight[frame];
                    break;
                case -1:
                    this.actualSprite=this.walkLeft[frame];
                    break;
            }
        }
        
        //Change frame
        this.steps+=1;
        if(this.steps>4) //This defines how long a frame is going to play
        {
            
            this.frame += 1;
            this.steps=0;
        }
      
        //Restart Walking Animation
        if(this.frame == 8)
        {
            frame = 0;
        }
    }
    
    public void setIdle()
    {
        this.frame = 0;
        
        if(Greenfoot.isKeyDown("k"))//Get Aiming images
        {
            switch(this.rotation)
            {
                case 0:
                    this.actualSprite=pointRight;
                    break;
                case 90:
                    this.actualSprite=pointFront;
                    break;
                case 180:
                    this.actualSprite=pointLeft;
                    break;
                case 270:
                    this.actualSprite=pointBack;
                    break;
            }
        }
        else //Get idleImages
        {
            switch(this.rotation)
            {
                case 0:
                    this.actualSprite=idleRight;
                    break;
                case 90:
                    this.actualSprite=idleFront;
                    break;
                case 180:
                    this.actualSprite=idleLeft;
                    break;
                case 270:
                    this.actualSprite=idleBack;
                    break;
            }
        }
    }
    
    public void playAnimations()
    {
        //Draw Current sprite
        this.actualSprite.scale(this.width,this.height);
        setImage(this.actualSprite);
        if(this.directionY!=0||this.directionX!=0)
        {
            walkingAnimations();
        }
        else
        {
            setIdle();
        }
    }
    
    public void topDownMovement()
    {
        //PlayAnimations
        if(this.directionY!=0||this.directionX!=0)//Move only if at least one direction is detected
        {
            int newX = getX() + (speed * directionX);
            int newY = getY() + (speed * directionY);
            setLocation(newX, newY);
        }
    }
    
    public void act()
    {
        if(hitStun)
            cooldownStun();
        
        this.checkInput();
        this.topDownMovement();
        this.playAnimations();
        //youAreDead();
        checkForDoor();
    }
}
