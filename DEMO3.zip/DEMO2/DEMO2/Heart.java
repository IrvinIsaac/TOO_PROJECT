import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Heart here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Heart extends Actor
{
    private GreenfootImage actualSprite = new GreenfootImage("Heart.png");
    
    public void act()
    {
        // Add your action code here.
        setImage(actualSprite);
    }
    
    public void changeSysmbol(GreenfootImage newSymbol)
    {
        actualSprite = newSymbol;
    }
}
