import greenfoot.*; 
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class BossOrc extends Enemy
{
    private int cooldown = 60; // Cooldown to attack
    private int currentCooldown = 0;
    private Player1 targetPlayer;
    private boolean moveClock = true;
    private int frame = 0;
    private int frameSteps = 0;
    private GreenfootImage walkDown[] = {new GreenfootImage("OrcWalkLeft1.png"), new GreenfootImage("OrcWalkLeft2.png"), new GreenfootImage("OrcWalkLeft3.png"), new GreenfootImage("OrcWalkLeft4.png"), new GreenfootImage("OrcWalkLeft5.png"), new GreenfootImage("OrcWalkLeft7.png"), new GreenfootImage("OrcWalkLeft8.png")};
    private GreenfootImage walkUp[] = {new GreenfootImage("OrcWalkRight1.png"), new GreenfootImage("OrcWalkRight2.png"), new GreenfootImage("OrcWalkRight3.png"), new GreenfootImage("OrcWalkRight4.png"), new GreenfootImage("OrcWalkRight5.png"), new GreenfootImage("OrcWalkRight6.png"), new GreenfootImage("OrcWalkRight7.png")};
    private GreenfootImage walkLeft[] = {new GreenfootImage("OrcWalkSideLeft1.png"), new GreenfootImage("OrcWalkSideLeft2.png"), new GreenfootImage("OrcWalkSideLeft3.png"), new GreenfootImage("OrcWalkSideLeft4.png"), new GreenfootImage("OrcWalkSideLeft5.png"), new GreenfootImage("OrcWalkSideLeft6.png"), new GreenfootImage("OrcWalkSideLeft7.png")};
    private GreenfootImage walkRight[] = {new GreenfootImage("OrcWalkSideRight1.png"), new GreenfootImage("OrcWalkSideRight2.png"), new GreenfootImage("OrcWalkSideRight3.png"), new GreenfootImage("OrcWalkSideRight4.png"), new GreenfootImage("OrcWalkSideRight5.png"), new GreenfootImage("OrcWalkSideRight6.png"), new GreenfootImage("OrcWalkSideRight7.png")};
    private GreenfootImage actualSprite;
    private int direction = 0;
      
    public BossOrc(int lifes, int speed,Score playerScore) {
        super(lifes, speed,playerScore);
        this.actualSprite = this.walkDown[0];
    }
    
    public void act()
    {
        if (!isDeath()){
            hostileState();
            moveAroundEdge();
            playAnimations();
        } else {
            killEnemy();
        }
    }
    
 private void moveAroundEdge() {
    int distance = getSpeed(); // Distancia de movimiento

    // Calcular la posición futura
    int futureX = getX();
    int futureY = getY();
    
    switch (direction){
        case 0: futureX += distance;
        break;
        case 1: futureY += distance;
        break;
        case 2: futureX -= distance;
        break;
        case 3: futureY -= distance;
        break;
    }

    // Verificar la casilla adyacente en la dirección actual
    if (canMoveForward(futureX, futureY)) {
        setLocation(futureX, futureY); // Moverse hacia adelante
    } else {
        // Si la próxima casilla en la dirección actual es una "W" o "L", girar en sentido horario o antihorario
        direction = (direction +1)%4;
    }
}

private boolean canMoveForward(int futureX, int futureY) {
    // Verificar si la casilla siguiente en la dirección actual es una "W" o "L"
    Actor obstacle = getOneObjectAtOffset(futureX - getX() + 32, futureY - getY() + 32, Obstacle.class);
    Actor obstacle1 = getOneObjectAtOffset(futureX - getX() - 32, futureY - getY() - 32, Obstacle.class);
    if (obstacle instanceof Cyberwall || obstacle instanceof CyberLatWall || obstacle1 instanceof Cyberwall || obstacle1 instanceof CyberLatWall) {
        return false; // No puede moverse hacia adelante (obstáculo detectado)
    }
    return true; // Puede moverse hacia adelante
}


public void walkingAnimations(){
    if (direction == 2){
        this.actualSprite = this.walkDown[frame];
    } else { if(direction == 0){
        this.actualSprite = this.walkUp[frame];
    } else { if(direction == 1){
        this.actualSprite = this.walkLeft[frame];
    } else { if(direction == 3){
        this.actualSprite = this.walkRight[frame];
    }
}
}
}
this.frameSteps += 1;
        if (this.frameSteps > 4) {
            this.frame += 1;
            this.frameSteps = 0;
        }
        if (this.frame == 7) {
            frame = 0;
        }
}

public void playAnimations(){
    walkingAnimations();
    setImage(this.actualSprite);
}
    
    public void pacificState(){
        
    }
    
    private void projectiles() 
    {
        Player1 player = findNearestPlayer(); // Encontrar al jugador más cercano
    if (player != null) {
        int playerX = player.getX();
        int playerY = player.getY();

        // Calcular el ángulo hacia el jugador
        int dx = playerX - getX();
        int dy = playerY - getY();
        double angleRadians = Math.atan2(dy, dx);
        int angleDegrees = (int) Math.toDegrees(angleRadians);

        // Crear y agregar los proyectiles con diferentes ángulos
        int angleOffset1 = 0;
        int angleOffset2 = 15;
        int angleOffset3 = -20;

        // Crear instancias de proyectiles con ángulos calculados
        Projectile projectile1 = new Projectile(angleDegrees + angleOffset1);
        Projectile projectile2 = new Projectile(angleDegrees + angleOffset2);
        Projectile projectile3 = new Projectile(angleDegrees + angleOffset3);

        // Agregar proyectiles al mundo en la posición del BossOrc
        getWorld().addObject(projectile1, getX(), getY());
        getWorld().addObject(projectile2, getX(), getY());
        getWorld().addObject(projectile3, getX(), getY());
    }
    }
    
    public void hostileState() {
        Actor objectCollided = getOneIntersectingObject(null);

        if (currentCooldown <= 0 && !(objectCollided instanceof Obstacle)){
                projectiles();
             
            currentCooldown = cooldown;
        } else {
            currentCooldown--;
        }
    }
    
    private Player1 findNearestPlayer() {
        List<Player1> players = getObjectsInRange(400, Player1.class);//Player in range
        if (!players.isEmpty()) {
            return players.get(0); // Devuelve el primer jugador en la lista
        }
        return null; // No se encontraron jugadores cercanos
    }
}
