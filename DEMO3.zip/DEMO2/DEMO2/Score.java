import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
/**
 * Class responsible to show the actual score of player 1
 */
public class Score extends Actor
{
    private GreenfootImage[] numbersImgs; //For storing all number digits images
    private ArrayList<Digit> digits;
    private int score;
    private int actualDigits = 1;
    
    public Score(int amountStart)
    {
        super();
        this.score=amountStart;
        this.numbersImgs = loadDigitsImages();
        digits = new ArrayList<Digit>();
    }
    
    public void act()
    {
        //Check if new digits are needed to be added or deleted
        if(!sameNumDigits())
            modifyDigitsAmount();
        
        //Update each digit in each new frame
        updateDigits();
    }
    
    //Update score
    public void addScore(int amount)
    {
        score+=amount;
    }
    
    public void decreaseScore(int amount)
    {
        score-=amount;
    }
    
    public void setCounter(int amount)
    {
        score = amount;
    }
    
    //Load images of numbers
    private GreenfootImage[] loadDigitsImages()
    {
        GreenfootImage[] result = new GreenfootImage[10];
        //Load images
        for(int i=0;i<=9;i++)
        {
            String imagePath = i + "UI.png";
            result[i]=new GreenfootImage(imagePath);
        }
        return result;
    }
    
    
    //Check number of digits of score in comparison of arraylist of digits
    public boolean sameNumDigits()
    {
          return Integer.toString(score).length() == digits.size();
    }
    
    public void modifyDigitsAmount()
    {
        //Add more digits
        if(Integer.toString(score).length() > digits.size())
            addDigits(Integer.toString(score).length()-digits.size());
        else
            deleteDigits(digits.size()-Integer.toString(score).length());
    }
    
    //Add more new digits
    public void addDigits(int n) //n represents the amount of new digits that will be added
    {
        for(int i = 1; i <= n; i++)
        {
            Digit nuevoDigito = new Digit();
            //Add the new digit to the world
            getWorld().addObject(nuevoDigito,digits.get(digits.size()-1).getX()+32,getY());
            //Save it to its reference to the arraylist
            digits.add(nuevoDigito);
        }
    }
    
    public void deleteDigits(int n)
    {
        for(int i = 1; i <= n; i++)
        {
            Digit toDelete = new Digit();
            getWorld().removeObject(toDelete);
            digits.remove(toDelete);
        }
    }
    
    //For starting the score counter
    public void startScoreCounter(World w)
    {
        //Start the first digit of the score counter
        Digit nuevoDigito = new Digit();
        digits.add(nuevoDigito);
        //Add the initial digit the world right next to the score: text Image
        getWorld().addObject(nuevoDigito,getX()+96,getY());
    }
    
    //Update all digits in each frame that passes (Arralist size matches with number of digits)
    public void updateDigits()
    {
         String scoreString = Integer.toString(score);
         //Update each digit from the more significative to les significative
         for(int i = 0;i<scoreString.length();i++)
         {
             //Update each digit
             digits.get(i).updateDigit(setDigit(Character.toString(scoreString.charAt(i))));
         }
    }
    
    //Choose wich digit to assign according to the current digit we want to update
    public GreenfootImage setDigit(String d)
    {
        int numValue=Integer.parseInt(d);
        for(int i = 0; i<=9;i++)
        {
            if(i==numValue)
                return numbersImgs[i];
        }
        return null;
    }
    
}
