import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
/**
 Class responsible for showing te actual lifes of character
 */
public class HeartBar extends Actor
{
    private ArrayList<Heart> healthBar = new ArrayList<Heart>();
    private GreenfootImage[] heartSymbol = {new GreenfootImage("Heart.png"),new GreenfootImage("EmptyHeart.png")};
    private int lifes;
    
    public HeartBar(int maxHealth)
    {    
        this.lifes = maxHealth;
    }
    
    public void act()
    {
        if(Greenfoot.isKeyDown("o"))
            takeDamage(1);
            
        if(Greenfoot.isKeyDown("p"))
            heal();
        
        updateHearts();
    }
    
    //Get player1 actual lifes
    public void getPlayerLifes(int playerLife)
    {
        this.lifes = playerLife;
    }
    
    //Update harts in each frame
    public void updateHearts()
    {
        for(int i = 0; i < healthBar.size();i++)
        {
            //Check wich symbol to assign
            if(healthBar.size()-lifes<=i) //Asign the hearts that player still haves
                healthBar.get(i).changeSysmbol(heartSymbol[0]);
            else
                healthBar.get(i).changeSysmbol(heartSymbol[1]);
        }
    }
    
    //Start healthBar with players maxHealth
    public void startHealthBar(World w)
    {
        int xPosStart = getX();
        for(int i=0;i<lifes;i++)
        {
            healthBar.add(new Heart());
            w.addObject(healthBar.get(healthBar.size()-1),xPosStart,getY());
            xPosStart+=40;
        }
    }
    
    //Voids for status to change or pass to player class
    public boolean isDeath()
    {
        return this.lifes==0;
    }
    
    public void heal()
    {
        if(lifes<=healthBar.size())
            lifes++;
    }
    
    public void takeDamage(int amount)
    {
        this.lifes-=amount;
        if(this.lifes<=0)
            this.lifes = 0;
    }
}
