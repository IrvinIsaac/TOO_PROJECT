import greenfoot.*;
import java.util.List;

public class CyberWorld1 extends World
{
    private int tileSize = 64;
    private int worldLength = 13;
    private int worldHeight = 10;
    private GInterface uiGameplay;
    private Player1 player = new Player1(5);
    private Enemy enemyTest = new LivingArmor(1,1,player.getPlayerScore());
    private Enemy enemyTest2 = new LivingArmor(1,1,player.getPlayerScore());
    private Enemy enemyTest3 = new Skeleton(1,1,player.getPlayerScore());
    
    private Enemy enemyTest5 = new BossOrc(2,1,player.getPlayerScore());
    
    private String[] stage =
        {
            "LWWWWWDWWWWWL",
            "LFFFFFFFFFFFL",
            "LFFFFFFFFFFFL",
            "LFFFFFFFFFFFL",
            "LFFFFFFFFFFFL",
            "LFFFFFFFFFFFL",
            "LFFFFFFFFFFFL",
            "LFFFFFFFFFFFL",
            "LFFFFFFFFFFFL",
            "LWWWWWWWWWWWL"
        };

    public CyberWorld1()
    {    
        super(832, 640, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        constructWorld(); //Add tilesto world
        //Add actors
        addActors();
        startUI();
        
    }

    public void addTile(char o, int x, int y)
    {
        Obstacle tile = null;

        switch(o)
        {
            case 'W':
                tile = new Cyberwall();
                break;
            case 'L':
                tile = new CyberLatWall();
                break;
            case 'D':
                tile = new CyberDoor();
                break;
        }

        if(tile != null)
        {
            addObject(tile, x * tileSize + tileSize / 2, y * tileSize + tileSize / 2);
        }

    }

    public void constructWorld() // Corrected method name
    {
        for(int i = 0; i < worldLength; i++)
        {
            for(int j = 0; j < worldHeight; j++)
            {
                addTile(stage[j].charAt(i), i, j);
            }
        }
    }
    
    public void addActors()
    {
        //Addplayer
        addObject(player,832/2,640/2);
        addObject(enemyTest,140,140);
        addObject(enemyTest2,832-128,640-128*2);
        addObject(enemyTest3,700,640/2);
      
        addObject(enemyTest5, 200, 200);
    }
    
    //
    public void startUI()
    {
        uiGameplay = new GInterface(player.getPlayerScore(),player.getLifes(),player.getInventory());
        //Add the gamplay interface to the world
        addObject(uiGameplay,0,0);
        uiGameplay.startUIElements();
    }
    
    public boolean areAllEnemiesDead(){
        List<Enemy> enemies = getObjects(Enemy.class);
        return enemies.isEmpty();
    }
    
    public void changeWorld(){
        Greenfoot.setWorld(new Congratulations());
    }
}
