import greenfoot.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class LivingArmor extends Enemy {
    private int cooldown = 70; // Cooldown to shoot
    private int currentCooldown = 0;
    private int steps;
    private boolean stop;
    private int directionX;
    private int directionY;
    private int decision;
    private int rotation;
    //Animation
    private int frameSteps = 0;
    private int frame = 0;
    private GreenfootImage[] idle = {new GreenfootImage("WizardIdleRight.png"),new GreenfootImage("WizardIdleLeft.png"),new GreenfootImage("WizardIdleFront.png")};
    private GreenfootImage[] walkRight = {new GreenfootImage("WizardWalkRight1.png"),new GreenfootImage("WizardWalkRight2.png"),new GreenfootImage("WizardWalkRight3.png"),new GreenfootImage("WizardWalkRight4.png"),new GreenfootImage("WizardWalkRight5.png"),new GreenfootImage("WizardWalkRight6.png"),new GreenfootImage("WizardWalkRight7.png"),new GreenfootImage("WizardWalkRight8.png")};
    private GreenfootImage[] walkLeft = {new GreenfootImage("WizardWalkLeft1.png"),new GreenfootImage("WizardWalkLeft2.png"),new GreenfootImage("WizardWalkLeft3.png"),new GreenfootImage("WizardWalkLeft4.png"),new GreenfootImage("WizardWalkLeft5.png"),new GreenfootImage("WizardWalkLeft6.png"),new GreenfootImage("WizardWalkLeft7.png"),new GreenfootImage("WizardWalkLeft8.png")};
    private GreenfootImage[] attack = {new GreenfootImage("WizardAttack1.png"),new GreenfootImage("WizardAttack2.png"),new GreenfootImage("WizardAttack3.png"),new GreenfootImage("WizardAttack4.png"),new GreenfootImage("WizardAttack5.png")};
    private GreenfootImage actualSprite = new GreenfootImage("WizardIdleFront.png");
    

    public LivingArmor(int lifes, int speed,Score playerScore) {
        super(lifes, speed,playerScore);
        this.steps = 0;
        this.directionX=0;
        this.directionY=0;
        this.stop = true;
        this.decision=0;
        this.rotation = 90;
    }

    public void act() {
        if (!isDeath()) {
            if (isHostile()) {
                hostileState();
            } else {
                pacificState();
                lookForPlayer();
            }
            
            playAnimations();
        } else {
            super.add(50);
            killEnemy();
        }
    }

    public void hostileState() {
        Player1 player = findNearestPlayer();
        if (player != null) {
            // Shoot projectiles towards the player
            shootProjectile(player);
        } else {
            changeHostileState(); //Change state if theres no player detected
            frame = 0;
            actualSprite = idle[2];
        }
    }
    
    public void isPlayerNearby(Player1 target) {
        // Calcular la distancia entre el LivingArmor y player
        double distance = Math.sqrt(Math.pow(getX()-target.getX(),2)+Math.pow(getX()-target.getX(),2));
        // Devolver verdadero si el jugador está dentro del rango de detección
        if(distance <= 300)
        {
          changeHostileState();
          frame = 0;
        }
    }
    
    public void lookForPlayer()
    {
      List<Player1> playerList = getObjectsInRange(300,Player1.class);
      if(!playerList.isEmpty())
      {
          for (Player1 player : playerList) 
          {
            if(!super.isHostile())
                isPlayerNearby(player);
          }
      }
    }
    
    public int chooseDirection() {
        Random rand = new Random();
        ArrayList<Integer> available = checkOptions();
        return available.get(rand.nextInt(available.size()));        
    }
    
    public boolean willCollide(Obstacle obj) {
        int objPosX = obj.getX();
        int objPosY = obj.getY();
        int enemyPosX = getX();
        int enemyPosY = getY();
        
        // Calculate the range of x and y positions for collision
        int minX = objPosX - 32;
        int maxX = objPosX + 32;
        int minY = objPosY - 32;
        int maxY = objPosY + 32;
    
        // Check if the LivingArmor's position falls within the collision range
        boolean collideX = enemyPosX + 64 >= minX && enemyPosX - 64 <= maxX;
        boolean collideY = enemyPosY + 64 >= minY && enemyPosY - 64 <= maxY;
        
        // Return true if there's a collision along both X and Y axes
        return collideX&&collideY;
    }
    
    public ArrayList<Integer> checkOptions() {
        List<Obstacle> obstacles = getWorld().getObjects(Obstacle.class);
        ArrayList<Integer> options = new ArrayList<>();
    
        // Add all directions initially
        options.add(1); // Right
        options.add(2); // Left
    
        // Check for obstacles and remove directions where collision will occur
        for (Obstacle obstacle : obstacles) {
            if (willCollide(obstacle)) {
                int objPosX = obstacle.getX();
                int objPosY = obstacle.getY();
                int enemyPosX = getX();
                int enemyPosY = getY();
                
                 // Calculate the range of x and y positions for collision
                    int minX = objPosX - 32;
                    int maxX = objPosX + 32;
                    int minY = objPosY - 32;
                    int maxY = objPosY + 32;
                System.out.println(options);
                // Determine direction of collision and remove corresponding option
                if (enemyPosX + 64 >= objPosX - 32 && enemyPosX + 64 <= objPosX+32) { // Right
                    options.remove(Integer.valueOf(1)); // Remove the Integer object, not the index
                } else if (enemyPosX - 64 <= objPosX + 32 && enemyPosX - 64 >= objPosX-32) { // Left
                    options.remove(Integer.valueOf(2));
                }
            }
        }
        
        //System.out.println(options);
        return options;
    }
    
    public void setMovement()
    {
        if(this.stop)
            this.stop=false;
        else
            this.stop=true;
    }
    
    public void movePacific(int newDir)
    {
        //Get actual position
        int newX = getX();
        int newY = getY();
        
        //Set the direction acording to the decision that was made
        switch(newDir)
        {
            case 1: //Go right
                this.directionY = 0;
                this.directionX = 1;
                this.rotation=0;
                break;
            case 2: //Go left
                this.directionY = 0;
                this.directionX = -1;
                this.rotation=180;
                break;
        }
        
        //Update to new position
        newX += (this.directionX*super.getSpeed());
        newY += (this.directionY*super.getSpeed());
        
        setLocation(newX,newY);
    }

    public void pacificState() {
        //Stop for only oneSecond
        if(this.steps>50)
        {
            this.directionX=0;
            this.directionY=0;
            this.decision=chooseDirection();
            this.steps=0;
            setMovement();
        }
        
        //Move only for one second
        if(!stop)
            movePacific(this.decision);
        
        this.steps+=1;
    }

    private void shootProjectile(Player1 player) 
    {
            if (currentCooldown <= 0) {
                if(player != null){
                    int dx=player.getX()-getX();
                    int dy=player.getY()-getY();
                    double angleRadians = Math.atan2(dy, dx);
                    int angleDegrees = (int) Math.toDegrees(angleRadians);
        
                Projectile projectile = new Projectile(angleDegrees); // Crear instancia del proyectil
                getWorld().addObject(projectile, getX(), getY());
            }
         currentCooldown = cooldown; // Reiniciar el cooldown
            } else {
                currentCooldown--;
        }
    }

     private Player1 findNearestPlayer() {
        List<Player1> players = getObjectsInRange(300, Player1.class);//Player in range
        if (!players.isEmpty()) {
            return players.get(0); // Devuelve el primer jugador en la lista
        }
        return null; // No se encontraron jugadores cercanos
    }
    
    public void checkPlayerCollision()
    {
        Actor player = getOneIntersectingObject(Player1.class);
        if(player!=null)
            ((Player1)player).takeDamage();
    }
    
    //Animation methods
    public void setIdle()
    {
        frame = 0;
        switch(rotation)
        {
            case 0:
                actualSprite = idle[0];
                break;
            case 180:
                actualSprite = idle[1];
                break;
        }
    }
    
    public void actionAnimation(GreenfootImage[] wAnim)
    {
        actualSprite = wAnim[frame];
        int limit = (super.isHostile()) ? 5 : 8;
        
        if(frameSteps > 4){
            frameSteps = 0;
            frame++;
        }
        else
        {
            frameSteps++;
        }
        
        if(frame>=limit)
            frame = 0;
    }
    
    public void playAnimations()
    {
        if(!super.isHostile())
        {
            if(directionX<0)
                actionAnimation(walkLeft);
            else if(directionX>0)
                actionAnimation(walkRight);
            else
                setIdle();
        }
        else
        {
            actionAnimation(attack);
        }
        setImage(actualSprite);
    }
}

