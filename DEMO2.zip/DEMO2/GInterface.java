import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;

/**
 Class responsible for drawing all elements of ui in gamepay
 */
public class GInterface extends Actor
{
    private Score playerScore;
    private HeartBar healthBar;
    private WeaponInventory uiInveontory;
    
    public GInterface(Score playerScore,HeartBar healthBar,WeaponInventory w)
    {
        this.playerScore = playerScore;
        this.healthBar = healthBar;
        this.uiInveontory = w;
    }
    
    //AddUIelements to the world wher Ginterface is
    public void startUIElements()
    {
        //Add elements to the world
        getWorld().addObject(playerScore,96-24,36);
        getWorld().addObject(healthBar,650,30);
        getWorld().addObject(uiInveontory,32,600);
        uiInveontory.addWeaponCounter();
        healthBar.startHealthBar(getWorld());
        playerScore.startScoreCounter(getWorld());
    }
    
    public void eraseUIElements()
    {
        getWorld().removeObject(playerScore);
        getWorld().removeObject(healthBar);
    }
}
