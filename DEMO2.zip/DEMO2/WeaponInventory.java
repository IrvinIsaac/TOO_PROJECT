import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;

/**
 * Write a description of class WeaponInventory here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WeaponInventory extends Actor
{
    /**
      class in charge of handling the weapon inventory
     */
    
    private static ArrayList<Weapon> inventory;
    private int currentIndex = 0;
    private int maxCapacity = 2;
    Score ammoCounter;
    Weapon currentWeapon;
    
    public WeaponInventory()
    {
        inventory = new ArrayList<>();
         ammoCounter = new Score(0);
    }
    
    //If the game first starts with an initial weapon
    public WeaponInventory(Weapon w)
    {
        inventory = new ArrayList<>();
        inventory.add(w);
        currentWeapon=w;
        ammoCounter = new Score(0);
    }
    
    public void act()
    {
       updateWeaponSymbol();
       if(currentWeapon!=null)
           ammoCounter.setCounter(currentWeapon.getAmmo());
    }
    
    //Methods
    public Weapon changeWeapon()
    {
        if(!inventory.isEmpty())
        {
            if(inventory.size()==currentIndex+1)
               currentIndex = 0; 
            else
               currentIndex++; 
            currentWeapon = inventory.get(currentIndex);
            
        }
        else
        {
            currentWeapon = null;
        }
        return currentWeapon;
    }
    
    public void addWeapon(Weapon w)
    {
        if(inventory.size()!=2)
        {   inventory.add(w);
            getWorld().removeObject(w);
        }
    }
    
    public void updateWeaponSymbol()
    {
        if(currentWeapon!=null)
        {
            switch(currentWeapon.getType())
            {
                case 1:
                    setImage("BasicGun.png");
                    break;
                case 2:
                    setImage("shotgun.png");
                    break;
            }
        }
        else
        {
            setImage("NoWeapon.png");
        }
    }
    
    public void addWeaponCounter()
    {
        getWorld().addObject(ammoCounter,getX()+100,getY());
        ammoCounter.startScoreCounter(getWorld());
        ammoCounter.setImage("AMMOUI.png");
    }
}
