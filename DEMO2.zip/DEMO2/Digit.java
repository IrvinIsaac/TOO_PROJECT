import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Class to represent a single digit
 */
public class Digit extends Actor
{
    private GreenfootImage digit = new GreenfootImage("0UI.png");
    
    public Digit()
    {
        super(); 
    }
    
    
    public void act()
    {
        //Draw current digit
        setImage(digit);
    }
    
    //Change the actual digit
    public void updateDigit(GreenfootImage newDigit)
    {
        digit = newDigit;
    }
    
    //Delete digit
    public void removeDigit()
    {
        getWorld().removeObject(this);
    }
}
